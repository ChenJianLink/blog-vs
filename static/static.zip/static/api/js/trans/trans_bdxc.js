window._bd_share_main.F.module("trans/trans_bdxc", function (e, t) {
    var n = function () {
        var e = window, t = document, n = "_bdXC", r;
        e[n] ? window._bdXC_loaded && e[n].reInit() : (r = t.createElement("script"), r.setAttribute("charset", "utf-8"), r.src = "http://xiangce.baidu.com/zt/collect/mark.js?" + (new Date).getTime(), t.getElementsByTagName("head")[0].appendChild(r))
    };
    t.run = n
});