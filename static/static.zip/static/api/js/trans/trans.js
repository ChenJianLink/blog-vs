!window._bd_share_is_recently_loaded && window._bd_share_main.F.module("trans/trans", function (e, t) {
    var n = e("component/comm_tools"), r = e("conf/const").URLS, i = function () {
        window._bd_share_main.F.use("base/tangram", function (e) {
            var t = e.T;
            t.cookie.get("bdshare_firstime") == null && t.cookie.set("bdshare_firstime", new Date * 1, {
                path: "/",
                expires: (new Date).setFullYear(2022) - new Date
            })
        })
    }, s = function (e) {
        var t = e.bdUrl || n.getPageUrl();
        return t = t.replace(/\'/g, "%27").replace(/\"/g, "%22"), t
    }, o = function (e) {
        var t = (new Date).getTime() + 3e3, r = {
            click: 1,
            url: s(e),
            uid: e.bdUid || "0",
            to: e.__cmd,
            type: "text",
            pic: e.bdPic || "",
            title: (e.bdText || document.title).substr(0, 300),
            key: (e.bdSnsKey || {})[e.__cmd] || "",
            desc: e.bdDesc || "",
            comment: e.bdComment || "",
            relateUid: e.bdWbuid || "",
            searchPic: e.bdSearchPic || 0,
            sign: e.bdSign || "on",
            l: window._bd_share_main.n1.toString(32) + window._bd_share_main.n2.toString(32) + t.toString(32),
            linkid: n.getLinkId(),
            firstime: a("bdshare_firstime") || ""
        };
        switch (e.__cmd) {
            case"copy":
                l(r);
                break;
            case"print":
                c();
                break;
            case"bdxc":
                h();
                break;
            case"bdysc":
                p(r);
                break;
            case"weixin":
                d(r);
                break;
            default:
                u(e, r)
        }
        window._bd_share_main.F.use("trans/logger", function (t) {
            t.commit(e, r)
        })
    }, u = function (e, t) {
        var n = r.jumpUrl;
        e.__cmd == "mshare" ? n = r.mshareUrl : e.__cmd == "mail" && (n = r.emailUrl);
        var i = n + "?" + f(t);
        window.open(i)
    }, a = function (e) {
        if (e) {
            var t = new RegExp("(^| )" + e + "=([^;]*)(;|$)"), n = t.exec(document.cookie);
            if (n) return decodeURIComponent(n[2] || null)
        }
    }, f = function (e) {
        var t = [];
        for (var n in e) t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]));
        return t.join("&").replace(/%20/g, "+")
    }, l = function (e) {
        window._bd_share_main.F.use("base/tangram", function (t) {
            var r = t.T;
            r.browser.ie ? (window.clipboardData.setData("text", document.title + " " + (e.bdUrl || n.getPageUrl())), alert("\u6807\u9898\u548c\u94fe\u63a5\u590d\u5236\u6210\u529f\uff0c\u60a8\u53ef\u4ee5\u63a8\u8350\u7ed9QQ/MSN\u4e0a\u7684\u597d\u53cb\u4e86\uff01")) : window.prompt("\u60a8\u4f7f\u7528\u7684\u662f\u975eIE\u6838\u5fc3\u6d4f\u89c8\u5668\uff0c\u8bf7\u6309\u4e0b Ctrl+C \u590d\u5236\u4ee3\u7801\u5230\u526a\u8d34\u677f", document.title + " " + (e.bdUrl || n.getPageUrl()))
        })
    }, c = function () {
        window.print()
    }, h = function () {
        window._bd_share_main.F.use("trans/trans_bdxc", function (e) {
            e && e.run()
        })
    }, p = function (e) {
        window._bd_share_main.F.use("trans/trans_bdysc", function (t) {
            t && t.run(e)
        })
    }, d = function (e) {
        window._bd_share_main.F.use("trans/trans_weixin", function (t) {
            t && t.run(e)
        })
    }, v = function (e) {
        o(e)
    };
    t.run = v, i()
});